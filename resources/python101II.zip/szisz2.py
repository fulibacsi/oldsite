# encoding: utf-8
# Util file for the Python101 - SzISz course 2nd class.

#imports
import os
import csv
import random
import operator
import webbrowser
import IPython.display

# globals
OR = operator.or_
AND = operator.and_

# Image print
def print_image(source, _type='img', width=None, height=None):
    """Display an image.
    Arguments:
        source: image URI.
        _type: the type of the image. available values:
            - net: URL
            - svg: svg image
            - img: standard image
        _width: display width
        _height: display height
    """
    if _type == 'net':
        IPython.display.display(
            IPython.display.Image(url=source, width=width, height=height)
        )
    elif _type == 'img':
        IPython.display.display(
            IPython.display.Image(filename=source, width=width, height=height)
        )
    elif _type == 'svg':
        IPython.display.display(
            IPython.display.SVG(source, width, height)
        )

# CSV reader
def import_from_csv(filename):
    """Returns the rows from the specified csv file."""
    data = []
    with open(filename, 'r') as csvfile:
        CSV = csv.reader(csvfile, dialect='excel')
        for row in CSV:
            data.append(row)
    return data

# CSV writer
def export_to_csv(filename, data):
    """Writes the data lines into a csv file."""
    if '.csv' not in filename:
        filename += '.csv'
    with open(filename, 'w') as csvfile:
        CSV = csv.writer(csvfile, dialect='excel')
        for row in data:
            CSV.writerow(row)

# file listing
def list_files(target_dir=''):
    """Returns the files from the specified directory. (default: current)
    Argument:
        target_dir - subdirectory name. default: working directory."""
    if len(target_dir):
        if not target_dir[0] == '/':
            target_dir = '/' + target_dir
    return [_file
        for _file in os.listdir('.' + target_dir)
        if os.path.isfile('.' + target_dir + '/' + _file)
    ]

# fake download function
def download(name='super_series', _season=7, _episodes=24):
    """Download the specified series into a directory.
    Arguments:
        name: name of the series. default: 'super_series'
        _season: the number of seasons. default: 7
        _episodes: the number of episodes in a season. default: 24"""
    try:
        seasons = xrange(1, _season+1)
        episodes = xrange(1, _episodes+1)
        movie_ext = 'avi'
        subtitle_ext = 'srt'
        filename = '{filename}.S{season}E{episode}.{extension}'
        subdir = './' + name
        try:
            os.mkdir(subdir)
        except:
            pass
        [open(subdir + '/' + filename.format(
            filename=name,
            season=str(season).zfill(2),
            episode=str(episode).zfill(2),
            extension=extension), 'w').write(
                filename.format(
                    filename=name,
                    season=str(season).zfill(2),
                    episode=str(episode).zfill(2),
                    extension=extension
                )
            )
            for extension in [movie_ext, subtitle_ext]
            for episode in episodes
            for season in seasons
        ]
    except Exception as e:
        return 'Creation process failed, ERROR:', e.message
    else:
        return 'Creation successful.'